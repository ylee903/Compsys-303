/*
 * main.c — COMPSYS303 Pacemaker, overhauled structure (SCCharts + C‑mode)
 *
 * Switches:
 *   SW0 = 0 → SCCharts, 1 → C‑mode
 *   SW1 = 0 → Buttons input, 1 → UART input
 *
 * Keys (active‑low):
 *   KEY1 → AS,  KEY0 → VS
 *
 * LEDs:
 *   LEDG1 ← AP, LEDG0 ← VP
 *   LEDR[1:0] mirror SW[1:0]
 */

#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

#include <system.h>
#include <alt_types.h>
#include <altera_avalon_pio_regs.h>
#include <sys/alt_timestamp.h>

#include "timing.h"
#include "Pacemaker.h"      /* SCCharts */
#include "Pacemaker_C.h"    /* C‑mode   */

#ifndef UART_NAME
#  define UART_NAME "/dev/uart"
#endif

/* ----------------------- App wiring & helpers ----------------------- */
#define SW_MASK_MODE   0x01  /* SW0 */
#define SW_MASK_SOURCE 0x02  /* SW1 */

#define LEDG_AP 0x02
#define LEDG_VP 0x01

typedef struct {
  int   fd_uart;
  alt_u32 hb_last_ms;
  alt_u32 ts_prev;
  alt_u32 keys_prev;   /* for edge detect */

  TickData sc;
  PacemakerC c;
  int c_booted;
} App;

static alt_u32 app_millis(void){
  alt_u64 t = alt_timestamp();
  alt_u32 f = alt_timestamp_freq();
  if (!f) return 0;
  return (alt_u32)((t * 1000ULL) / f);
}

static void leds_show_switches(alt_u32 sw){
  IOWR_ALTERA_AVALON_PIO_DATA(LEDS_RED_BASE, (sw & 0x03));
}

static void leds_set_green(alt_u32 bits){
  IOWR_ALTERA_AVALON_PIO_DATA(LEDS_GREEN_BASE, bits);
}

static void uart_probe(App* a){
  if (a->fd_uart >= 0){
    const char *msg = "HELLO_FROM_BOARD\r\n";
    (void)write(a->fd_uart, msg, (int)strlen(msg));
  }
}

static void hb_tick(App* a){
  const alt_u32 now = app_millis();
  if (now - a->hb_last_ms >= 1000){
    a->hb_last_ms = now;
    printf("[beat] %ums\n", (unsigned)now);
    fflush(stdout);
  }
}

static void sccharts_inputs_from_buttons(App* a){
  alt_u32 k = IORD_ALTERA_AVALON_PIO_DATA(KEYS_BASE);
  int as_edge = ((a->keys_prev & 0x02) != 0) && ((k & 0x02) == 0);
  int vs_edge = ((a->keys_prev & 0x01) != 0) && ((k & 0x01) == 0);
  if (as_edge){ a->sc.AS = 1; printf("[keys] AS (KEY1)\n"); }
  if (vs_edge){ a->sc.VS = 1; printf("[keys] VS (KEY0)\n"); }
  a->keys_prev = k;
}

static void sccharts_inputs_from_uart(App* a){
  char ch; int n;
  while ((n = read(a->fd_uart, &ch, 1)) > 0){
    if (ch=='A'||ch=='a') a->sc.AS = 1;
    if (ch=='V'||ch=='v') a->sc.VS = 1;
  }
}

static void sccharts_outputs(App* a, int uart_enabled){
  alt_u32 g = 0;
  if (a->sc.AP) g |= LEDG_AP;
  if (a->sc.VP) g |= LEDG_VP;
  leds_set_green(g);

  if (uart_enabled && a->fd_uart >= 0){
    if (a->sc.AP){ const char A='A'; (void)write(a->fd_uart,&A,1); }
    if (a->sc.VP){ const char V='V'; (void)write(a->fd_uart,&V,1); }
  }
}

static void app_sccharts_step(App* a, int uart_enabled){
  alt_u32 now = alt_timestamp();
  alt_u32 dt  = now - a->ts_prev;
  a->ts_prev  = now;
  a->sc.deltaT = (double)dt * 1000.0 / (double)alt_timestamp_freq();

  if (uart_enabled) sccharts_inputs_from_uart(a);
  else              sccharts_inputs_from_buttons(a);

  tick(&a->sc);
  sccharts_outputs(a, uart_enabled);

  a->sc.AS = 0; a->sc.VS = 0; /* one‑tick pulses */
}

/* ----------------------- C‑mode glue ----------------------- */
static void cmode_inputs(App* a, int uart_enabled, int* AS_raw, int* VS_raw){
  *AS_raw = 0; *VS_raw = 0;
  if (uart_enabled){
    char ch; int n;
    while ((n = read(a->fd_uart, &ch, 1)) > 0){
      if (ch=='A'||ch=='a') *AS_raw = 1;
      if (ch=='V'||ch=='v') *VS_raw = 1;
    }
  } else {
    alt_u32 k = IORD_ALTERA_AVALON_PIO_DATA(KEYS_BASE);
    int as_edge = ((a->keys_prev & 0x02) != 0) && ((k & 0x02) == 0);
    int vs_edge = ((a->keys_prev & 0x01) != 0) && ((k & 0x01) == 0);
    if (as_edge){ *AS_raw = 1; printf("[keys] AS (KEY1)\n"); }
    if (vs_edge){ *VS_raw = 1; printf("[keys] VS (KEY0)\n"); }
    a->keys_prev = k;
  }
}

static void cmode_outputs(App* a, int uart_enabled){
  alt_u32 g = 0;
  if (PMc_led_AP_on(&a->c)) g |= LEDG_AP;
  if (PMc_led_VP_on(&a->c)) g |= LEDG_VP;
  leds_set_green(g);

  if (uart_enabled && a->fd_uart >= 0){
    int ap_any=0, vp_any=0;
    PMc_poll_and_clear_pulses(&a->c, &ap_any, &vp_any);
    if (ap_any){ const char A='A'; (void)write(a->fd_uart,&A,1); }
    if (vp_any){ const char V='V'; (void)write(a->fd_uart,&V,1); }
  }
}

static void app_cmode_step(App* a, int uart_enabled){
  if (!a->c_booted){
    PMc_init(&a->c);
    PMc_set_led_pulse_ms(&a->c, 25);
    a->c_booted = 1;
  }

  {
    int asr, vsr;
    cmode_inputs(a, uart_enabled, &asr, &vsr);
    PMc_set_senses(&a->c, asr, vsr);
  }

  PMc_run_for_elapsed_ms(&a->c);
  cmode_outputs(a, uart_enabled);
}

/* ----------------------- Entry point ----------------------- */
int main(void){
  App app;
  memset(&app, 0, sizeof(app));

  reset(&app.sc);

  if (alt_timestamp_start() < 0){
    printf("[err] alt_timestamp_start failed\n");
  }
  app.ts_prev     = alt_timestamp();
  app.hb_last_ms  = 0;
  app.keys_prev   = IORD_ALTERA_AVALON_PIO_DATA(KEYS_BASE);

  app.fd_uart = open(UART_NAME, O_RDWR | O_NONBLOCK);
  if (app.fd_uart < 0) printf("[err] open %s\n", UART_NAME);
  else { printf("[ok ] %s open\n", UART_NAME); uart_probe(&app); }
  fflush(stdout);

  printf("\n== Pacemaker — SCCharts + C‑mode ==\n");
  printf("Timings(ms): AVI=%d AEI=%d PVARP=%d VRP=%d LRI=%d URI=%d\n",
         AVI_VALUE, AEI_VALUE, PVARP_VALUE, VRP_VALUE, LRI_VALUE, URI_VALUE);
  printf("SW0:0 SCCharts,1 C  |  SW1:0 Buttons,1 UART\n\n");

  for(;;){
    alt_u32 sw = IORD_ALTERA_AVALON_PIO_DATA(SWITCHES_BASE);
    leds_show_switches(sw);

    /* source/mode decode */
    const int use_sccharts = ((sw & SW_MASK_MODE) == 0);
    const int use_uart     = ((sw & SW_MASK_SOURCE) != 0);

    if (use_sccharts) app_sccharts_step(&app, use_uart);
    else              app_cmode_step(&app, use_uart);

    hb_tick(&app);
  }

  return 0;
}
