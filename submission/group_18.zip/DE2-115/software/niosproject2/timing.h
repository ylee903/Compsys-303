/*
 * timing.h
 *
 *  Created on: 15/10/2025
 *      Author: ylee903
 */


// timing.h � all times in milliseconds
#define AVI_VALUE 300
#define AEI_VALUE 800
#define PVARP_VALUE 50
#define VRP_VALUE 150
#define LRI_VALUE 2000
#define URI_VALUE 0

